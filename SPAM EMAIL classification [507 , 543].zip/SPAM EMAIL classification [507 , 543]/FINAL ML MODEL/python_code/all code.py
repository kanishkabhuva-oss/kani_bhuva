# ============================================================
# SPAM EMAIL DETECTION - MACHINE LEARNING PROJECT
# ============================================================
# Project Members:
# 1. KANISHKA BHUVA - Roll No. 507
# 2. RUDRA HINGLADIYA - Roll No. 543
#
# Dataset:
# 2500 records | 10 fields
# Target: spam / not spam
#
# Algorithm:
# TF-IDF + Logistic Regression
# ============================================================


# ------------------------------------------------------------
# 1. IMPORT REQUIRED LIBRARIES
# ------------------------------------------------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
import os
import pickle

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix
)

from sklearn.pipeline import Pipeline


# ------------------------------------------------------------
# 2. PROJECT INFORMATION
# ------------------------------------------------------------

print("=" * 70)
print("              SPAM EMAIL DETECTION PROJECT")
print("=" * 70)

print("Project Members:")
print("KANISHKA BHUVA - Roll No. 507")
print("RUDRA HINGLADIYA - Roll No. 543")
print()


# ------------------------------------------------------------
# 3. LOAD DATASET
# ------------------------------------------------------------

file_path = "C:\\Users\\YUG BHUVA\\Downloads\\SPAM EMAIL classification [507 , 543]\\FINAL ML MODEL\\\\Dataset\\\\spam_email_2500_10_fields.csv"

df=pd.read_csv(file_path)

print("\nDataset loaded successfully.")
print("Number of rows:", df.shape[0])
print("Number of columns:", df.shape[1])


# ------------------------------------------------------------
# 4. DISPLAY FIRST RECORDS
# ------------------------------------------------------------

print("\nFirst 5 records:")
print(df.head())


# ------------------------------------------------------------
# 5. DISPLAY LAST RECORDS
# ------------------------------------------------------------

print("\nLast 5 records:")
print(df.tail())


# ------------------------------------------------------------
# 6. DATASET INFORMATION
# ------------------------------------------------------------

print("\nDataset Information:")
print(df.info())


# ------------------------------------------------------------
# 7. CHECK COLUMN NAMES
# ------------------------------------------------------------

print("\nColumn Names:")
print(df.columns.tolist())


# ------------------------------------------------------------
# 8. CHECK DATA TYPES
# ------------------------------------------------------------

print("\nData Types:")
print(df.dtypes)


# ------------------------------------------------------------
# 9. CHECK MISSING VALUES
# ------------------------------------------------------------

print("\nMissing Values:")
print(df.isnull().sum())


# ------------------------------------------------------------
# 10. CHECK DUPLICATE RECORDS
# ------------------------------------------------------------

print("\nNumber of duplicate records:")
print(df.duplicated().sum())


# ------------------------------------------------------------
# 11. REMOVE DUPLICATES
# ------------------------------------------------------------

df = df.drop_duplicates()

print("\nDataset shape after removing duplicates:")
print(df.shape)


# ------------------------------------------------------------
# 12. HANDLE MISSING TEXT VALUES
# ------------------------------------------------------------

df["Subject"] = df["Subject"].fillna("")
df["Email_Body"] = df["Email_Body"].fillna("")
df["Label"] = df["Label"].fillna("not spam")


# ------------------------------------------------------------
# 13. CHECK TARGET CLASSES
# ------------------------------------------------------------

print("\nTarget Classes:")
print(df["Label"].value_counts())


# ------------------------------------------------------------
# 14. CLASS DISTRIBUTION
# ------------------------------------------------------------

plt.figure(figsize=(7, 5))

sns.countplot(
    data=df,
    x="Label",
    order=["spam", "not spam"]
)

plt.title("Spam vs Not Spam Distribution")
plt.xlabel("Email Class")
plt.ylabel("Number of Emails")
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 15. PIE CHART
# ------------------------------------------------------------

class_counts = df["Label"].value_counts()

plt.figure(figsize=(7, 7))

plt.pie(
    class_counts.values,
    labels=class_counts.index,
    autopct="%1.1f%%",
    startangle=90
)

plt.title("Spam and Not Spam Percentage")
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 16. CREATE COMBINED TEXT
# ------------------------------------------------------------

df["combined_text"] = (
    df["Subject"].astype(str)
    + " "
    + df["Email_Body"].astype(str)
)


# ------------------------------------------------------------
# 17. TEXT CLEANING FUNCTION
# ------------------------------------------------------------

def clean_text(text):

    text = text.lower()

    # Remove URLs
    text = re.sub(r"http\S+|www\S+", " ", text)

    # Remove email addresses
    text = re.sub(
        r"\S+@\S+",
        " ",
        text
    )

    # Remove special characters
    text = re.sub(
        r"[^a-zA-Z\s]",
        " ",
        text
    )

    # Remove extra spaces
    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text.strip()


# ------------------------------------------------------------
# 18. APPLY TEXT CLEANING
# ------------------------------------------------------------

df["clean_text"] = df["combined_text"].apply(clean_text)

print("\nSample cleaned text:")
print(df[["combined_text", "clean_text"]].head())


# ------------------------------------------------------------
# 19. WORD COUNT ANALYSIS
# ------------------------------------------------------------

df["calculated_word_count"] = (
    df["clean_text"].str.split().str.len()
)

plt.figure(figsize=(8, 5))

sns.boxplot(
    data=df,
    x="Label",
    y="calculated_word_count"
)

plt.title("Word Count Distribution")
plt.xlabel("Email Class")
plt.ylabel("Word Count")
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 20. CHARACTER COUNT ANALYSIS
# ------------------------------------------------------------

df["calculated_character_count"] = (
    df["clean_text"].str.len()
)

plt.figure(figsize=(8, 5))

sns.boxplot(
    data=df,
    x="Label",
    y="calculated_character_count"
)

plt.title("Character Count Distribution")
plt.xlabel("Email Class")
plt.ylabel("Character Count")
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 21. AVERAGE WORD COUNT
# ------------------------------------------------------------

average_words = (
    df.groupby("Label")["calculated_word_count"]
    .mean()
)

print("\nAverage Word Count:")
print(average_words)

plt.figure(figsize=(7, 5))

average_words.plot(kind="bar")

plt.title("Average Word Count by Email Class")
plt.xlabel("Email Class")
plt.ylabel("Average Word Count")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 22. LINK COUNT ANALYSIS
# ------------------------------------------------------------

df["calculated_link_count"] = df["combined_text"].apply(
    lambda x: len(re.findall(r"https?://|www\.", str(x), re.I))
)

link_average = (
    df.groupby("Label")["calculated_link_count"]
    .mean()
)

print("\nAverage Link Count:")
print(link_average)

plt.figure(figsize=(7, 5))

link_average.plot(kind="bar")

plt.title("Average Number of Links")
plt.xlabel("Email Class")
plt.ylabel("Average Link Count")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 23. EXCLAMATION COUNT
# ------------------------------------------------------------

df["calculated_exclamation_count"] = (
    df["combined_text"].str.count("!")
)

exclamation_average = (
    df.groupby("Label")["calculated_exclamation_count"]
    .mean()
)

print("\nAverage Exclamation Count:")
print(exclamation_average)


# ------------------------------------------------------------
# 24. FEATURE COMPARISON
# ------------------------------------------------------------

feature_columns = [
    "calculated_word_count",
    "calculated_character_count",
    "calculated_link_count",
    "calculated_exclamation_count"
]

feature_means = df.groupby("Label")[feature_columns].mean()

print("\nFeature Comparison:")
print(feature_means)


# ------------------------------------------------------------
# 25. TF-IDF FEATURE EXTRACTION
# ------------------------------------------------------------

X = df["clean_text"]
y = df["Label"]

vectorizer = TfidfVectorizer(
    stop_words="english",
    ngram_range=(1, 2),
    max_features=5000,
    min_df=2
)


# ------------------------------------------------------------
# 26. TRAIN TEST SPLIT
# ------------------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining records:", len(X_train))
print("Testing records:", len(X_test))


# ------------------------------------------------------------
# 27. CONVERT TEXT INTO TF-IDF
# ------------------------------------------------------------

X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

print("\nTF-IDF Training Shape:")
print(X_train_tfidf.shape)

print("\nTF-IDF Testing Shape:")
print(X_test_tfidf.shape)


# ------------------------------------------------------------
# 28. CREATE MACHINE LEARNING MODEL
# ------------------------------------------------------------

model = LogisticRegression(
    max_iter=1000,
    random_state=42
)


# ------------------------------------------------------------
# 29. TRAIN MODEL
# ------------------------------------------------------------

print("\nTraining Logistic Regression model...")

model.fit(
    X_train_tfidf,
    y_train
)

print("Model training completed.")


# ------------------------------------------------------------
# 30. MAKE PREDICTIONS
# ------------------------------------------------------------

y_pred = model.predict(
    X_test_tfidf
)


# ------------------------------------------------------------
# 31. CALCULATE ACCURACY
# ------------------------------------------------------------

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:")
print(accuracy)


# ------------------------------------------------------------
# 32. CALCULATE PRECISION
# ------------------------------------------------------------

precision = precision_score(
    y_test,
    y_pred,
    pos_label="spam",
    zero_division=0
)

print("\nPrecision:")
print(precision)


# ------------------------------------------------------------
# 33. CALCULATE RECALL
# ------------------------------------------------------------

recall = recall_score(
    y_test,
    y_pred,
    pos_label="spam",
    zero_division=0
)

print("\nRecall:")
print(recall)


# ------------------------------------------------------------
# 34. CALCULATE F1 SCORE
# ------------------------------------------------------------

f1 = f1_score(
    y_test,
    y_pred,
    pos_label="spam",
    zero_division=0
)

print("\nF1 Score:")
print(f1)


# ------------------------------------------------------------
# 35. COMPLETE CLASSIFICATION REPORT
# ------------------------------------------------------------

print("\nClassification Report:")
print(
    classification_report(
        y_test,
        y_pred,
        zero_division=0
    )
)


# ------------------------------------------------------------
# 36. CONFUSION MATRIX
# ------------------------------------------------------------

cm = confusion_matrix(
    y_test,
    y_pred,
    labels=["not spam", "spam"]
)

print("\nConfusion Matrix:")
print(cm)


# ------------------------------------------------------------
# 37. DISPLAY CONFUSION MATRIX
# ------------------------------------------------------------

plt.figure(figsize=(7, 5))

sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Not Spam", "Spam"],
    yticklabels=["Not Spam", "Spam"]
)

plt.title("Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("Actual Label")
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 38. MODEL PERFORMANCE GRAPH
# ------------------------------------------------------------

metrics = {
    "Accuracy": accuracy,
    "Precision": precision,
    "Recall": recall,
    "F1 Score": f1
}

plt.figure(figsize=(8, 5))

plt.bar(
    metrics.keys(),
    [value * 100 for value in metrics.values()]
)

plt.title("Model Performance")
plt.xlabel("Metric")
plt.ylabel("Percentage")

plt.ylim(0, 105)

for i, value in enumerate(metrics.values()):
    plt.text(
        i,
        value * 100 + 1,
        f"{value * 100:.2f}%",
        ha="center"
    )

plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 39. TEST A NEW EMAIL
# ------------------------------------------------------------

new_email = [
    "Congratulations! You have won a free cash reward. "
    "Click the link now to claim your prize!"
]

new_email_clean = [
    clean_text(new_email[0])
]

new_email_vector = vectorizer.transform(
    new_email_clean
)

prediction = model.predict(
    new_email_vector
)

print("\nNew Email:")
print(new_email[0])

print("\nPrediction:")
print(prediction[0])


# ------------------------------------------------------------
# 40. TEST A NORMAL EMAIL
# ------------------------------------------------------------

normal_email = [
    "Hello, please find the project report attached. "
    "Please review it and send your feedback."
]

normal_email_clean = [
    clean_text(normal_email[0])
]

normal_vector = vectorizer.transform(
    normal_email_clean
)

normal_prediction = model.predict(
    normal_vector
)

print("\nNormal Email:")
print(normal_email[0])

print("\nPrediction:")
print(normal_prediction[0])


# ------------------------------------------------------------
# 41. SAVE MODEL
# ------------------------------------------------------------

with open(
    "C:\\Users\\YUG BHUVA\\Downloads\\SPAM EMAIL classification [507 , 543]\\FINAL ML MODEL\\spam_email_model.pkl",
    "wb"
) as model_file:

    pickle.dump(
        model,
        model_file
    )


# ------------------------------------------------------------
# 42. SAVE TF-IDF VECTORIZER
# ------------------------------------------------------------

with open(
    "C:\\Users\\YUG BHUVA\\Downloads\\SPAM EMAIL classification [507 , 543]\\FINAL ML MODEL\\spam_email_vectorizer.pkl",
    "wb"
) as vectorizer_file:

    pickle.dump(
        vectorizer,
        vectorizer_file
    )


# ------------------------------------------------------------
# 43. FINAL PROJECT SUMMARY
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("                  PROJECT SUMMARY")
print("=" * 70)

print("Dataset Records :", len(df))
print("Dataset Fields  :", 10)
print("Training Records:", len(X_train))
print("Testing Records :", len(X_test))
print(f"Accuracy        : {accuracy * 100:.2f}%")
print(f"Precision       : {precision * 100:.2f}%")
print(f"Recall          : {recall * 100:.2f}%")
print(f"F1 Score        : {f1 * 100:.2f}%")

print("=" * 70)
print("             SPAM EMAIL DETECTION COMPLETE")
print("=" * 70)
